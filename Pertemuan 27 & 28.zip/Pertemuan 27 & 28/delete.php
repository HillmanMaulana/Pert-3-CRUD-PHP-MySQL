<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 delete</title>
</head>
<body>
	<?php 
		include 'lib/library.php';		

		$nis = $_GET['nis'];
		$mysqli->query("DELETE FROM siswa WHERE nis = '$nis'") or die(mysql_error());
		if (empty($siswa)) header('location: index.php');

		include 'views/v_tambah.php';
	?>
</body>
</html>