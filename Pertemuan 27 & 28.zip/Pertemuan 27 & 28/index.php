<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 index</title>
</head>
<body>
	<?php
		include 'lib/library.php';

		// tambah ini
		$success = flash('success');
		$error = flash('error');

		cekLogin();

		// Ada yang diubah
		// Dari sini
		$sql = "SELECT * FROM siswa
				INNER JOIN t_kelas ON (siswa.id_kelas = t_kelas.id_kelas)";

		$search = @$_GET['search'];
		if (!empty($search))$sql .= " WHERE nis LIKE '%$search%' OR nama_lengkap LIKE '%$search%' OR jenis_kelamin LIKE '%$search%' OR alamat LIKE '%$search%' OR golongan_darah LIKE '%$search%' OR nama_ibu LIKE '%$search%' ";
		// Sampai sini
		// Coba perhatikan

		$order_field = @$_GET['sort'];
		$order_mode = @$_GET['order'];
		if (!empty($order_field) && !empty($order_mode))$sql .= " ORDER BY $order_field $order_mode";

		$listSiswa = $mysqli->query($sql);

		include 'views/v_index.php';
	?>
</body>
</html>