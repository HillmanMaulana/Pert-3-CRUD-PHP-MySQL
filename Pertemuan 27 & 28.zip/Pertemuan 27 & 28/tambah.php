<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 tambah</title>
</head>
<body>
	<?php
		include 'lib/library.php';

		if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
			// Yang asalnya $_POST ubah jadi @$_POST begitupun yang $_FILES
			$nis 			= @$_POST['nis'];
			$nama_lengkap 	= @$_POST['nama_lengkap'];
			$jenis_kelamin 	= @$_POST['jenis_kelamin'];
			$kelas 	 		= @$_POST['id_kelas'];
			$jurusan 		= @$_POST['jurusan'];
			$alamat 		= @$_POST['alamat'];
			$golongan_darah = @$_POST['golongan_darah'];
			$nama_ibu 		= @$_POST['nama_ibu'];
			$foto 			= @$_FILES['foto'];
			
			// Dari sini
			if (empty($nis)) {
				flash('errorn', 'Mohon kolom NIS nya diisi !!!');
			}
			else if (empty($nama_lengkap)) {
				flash('errorl', 'Mohon kolom Nama Lengkap diisi !!!');
			} 
			else {
				// Ini kodingan yang waktu itu
				if (!empty($foto) AND $foto['error'] == 0) {
					$path = './assets/foto/';
					$upload = move_uploaded_file($foto['tmp_name'], $path . $foto['name']);

					if (!$upload) {
						flash('error', "Upload file gagal");
						header('location: index.php');
					}
					$file = $foto['name'];
				}

				$sql = "INSERT INTO siswa (nis, nama_lengkap, jenis_kelamin, id_kelas, 
										   jurusan, alamat, golongan_darah, nama_ibu, file) 
						VALUES('$nis', '$nama_lengkap', '$jenis_kelamin', '$kelas', 
							   '$jurusan', '$alamat', '$golongan_darah', '$nama_ibu', '$file')";

				$mysqli->query($sql) or die ($mysqli->error);
				header('location: index.php');
			}
		}
		$success;
		$errorNIS = flash('errorn');
		$errorNamaL = flash('errorl');
		// Sampai sini

		$sql = "SELECT * FROM t_kelas";
		$dataKelas = $mysqli->query($sql) or die($mysqli->error);

		include 'views/v_tambah.php';
	?>
</body>
</html>