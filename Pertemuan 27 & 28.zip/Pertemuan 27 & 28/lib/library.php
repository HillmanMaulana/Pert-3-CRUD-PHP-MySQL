<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 library database</title>
</head>
<body>
	<?php
		session_start();

		//Tambahkan fungsi ini
		function base_url() {
			//returnnya ke index awal masing-masing
			return "http://localhost/PWPB/Pertemuan%2027%20&%2028";
		}

		function flash($tipe, $pesan = ''){
			if (empty($pesan)) {
				$pesan = @$_SESSION[$tipe];
				unset($_SESSION[$tipe]);
				return $pesan;
			}
			else {
				$_SESSION[$tipe] = $pesan;
			}
		}

		function cekLogin(){
			$username = @$_SESSION['username'];
			$level = @$_SESSION['level'];

			if (empty($username) AND empty($level)) {
				header("location:login.php");
			}
		}

		function sudahLogin() {
			$username = @$_SESSION['username'];
			$level = @$_SESSION['level'];

			if (!empty($username) AND !empty($level)) {
				header("location:index.php");
			}
		}

		$host = 'localhost';
		$user = 'root';
		$pass = '';
		$db = 'db_pertemuan27';

		$mysqli = mysqli_connect($host, $user, $pass, $db)
				or die('Tidak dapat koneksi ke Database');
	?>
</body>
</html>