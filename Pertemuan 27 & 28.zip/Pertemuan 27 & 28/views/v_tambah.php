<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 view tambah</title>
	<link rel="stylesheet" type="text/css" href="assets/hiasP.css">
	<script type="text/javascript" src="assets/media/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/media/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/media/css/bootstrap.css">
	<!-- Toastr Plugin -->
	<link rel="stylesheet" type="text/css" href="assets/media/plugins/toastr/toastr.min.css">
	<script type="text/javascript" src="assets/media/plugins/toastr/toastr.min.js"></script>
</head>
<body>
<?php  
	$action = 'tambah.php';
	$ada = ' ';
	if (!empty($siswa)) {$action = 'edit.php'; $ada = 'readonly';}
?>

<?php if (!empty($success)) { ?>
	<div class="alert alert-success">
		<p><?= $success ?></p>
	</div>
<?php } ?>

<?php if (!empty($error)) { ?>
	<div class="alert alert-danger">
		<p>Error !!!</p>
	</div>
<?php } ?>

<form action="index.php" id="kembali">
	<input type="submit" name="reset" value="Kembali" class="btn btn-success">
</form>

<form id="tambah" action="<?= $action ?>" method="POST" enctype="multipart/form-data">
	<table id="tambah">
		<tr><td colspan="3" align="center" ><h2 class="teks" >Data Siswa</h2></td></tr>
		<tr>
			<td class="teks">NIS</td>
			<td>:</td>
			<td> <input type="text" name="nis" class="data" value="<?= @$siswa['nis']?>" <?=$ada?>></td>
		</tr>

		<!-- Tambahkan yang ini -->
		<tr>
			<td></td>
			<td></td>
			<td>
				<?php if (!empty($errorNIS)) { ?>
					<div class="alert alert-danger">
						<?= $errorNIS ?>
					</div>
				<?php } ?>
			</td>
		</tr>
		<!-- Sampai sini -->

		<tr>
			<td class="teks" >Nama Lengkap</td>
			<td>:</td>
			<td> <input type="text" name="nama_lengkap" class="data"  value="<?= @$siswa['nama_lengkap']?>"></td>
		</tr>

		<!-- Juga ini -->
		<tr>
			<td></td>
			<td></td>
			<td>
				<?php if (!empty($errorNamaL)) { ?>
					<div class="alert alert-danger">
						<?= $errorNamaL ?>
					</div>
				<?php } ?>
			</td>
		</tr>
		<!-- Sampai sini -->

		<tr>
			<td class="teks" >Jenis Kelamin</td>
			<td>:</td>
			<td> <input type="radio" class="teks" name="jenis_kelamin" value="L" <?= @$siswa['jenis_kelamin'] == 'L' ? 'checked' : ' '?>> Laki-Laki
				  <input type="radio" class="teks" name="jenis_kelamin" value="P" <?= @$siswa['jenis_kelamin'] == 'P' ? 'checked' : ' '?>> Perempuan
			</td>
		</tr>
		<!-- Dari sini -->
		<tr>
			<td class="teks" >Kelas</td>
			<td>:</td>
			<td> <select name="id_kelas">
					<option value=" ">[ Pilih Kelas ]</option>
					<?php while($row = mysqli_fetch_object($dataKelas)) { ?>
						<option value="<?php echo $row->id_kelas?>"
							<?php echo @$siswa['id_kelas'] == $row->id_kelas ? 'selected' : ''?>>
							<?php echo $row->nama_kelas?>
						</option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<!-- Sampai sini -->
		<tr>
			<td rowspan="2" valign="top" class="teks" >Alamat</td>
			<td rowspan="2" valign="top">:</td>
			<td rowspan="2" valign="top"> <textarea name="alamat" id="alamat" value="<?= @$siswa['alamat']?>"></textarea></td>
		</tr>
		<tr></tr>
		<tr>
			<td class="teks" >Golongan darah</td>
			<td>:</td>
			<td> <select name="golongan_darah">
					<option value="A" <?= @$siswa['golongan_darah'] == 'A' ? 'selected' : ' ' ?>>A</option>
					<option value="B" <?= @$siswa['golongan_darah'] == 'B' ? 'selected' : ' ' ?>>B</option>
					<option value="O" <?= @$siswa['golongan_darah'] == 'O' ? 'selected' : ' ' ?>>O</option>
					<option value="AB" <?= @$siswa['golongan_darah'] == 'AB' ? 'selected' : ' ' ?>>AB</option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="teks" >Nama Ibu</td>
			<td>:</td>
			<td> <input type="text" name="nama_ibu" class="data"  value="<?= @$siswa['nama_ibu']?>"></td>
		</tr>
		<!-- Tambahkan ini -->
		<tr>
			<td class="teks" >Foto</td>
			<td>:</td>
			<td>
				<?php if($action = 'edit.php') { ?>
				<img src="assets/foto/<?php echo @$siswa['file']?>" width="80px" alt=" "/>
				<input type="hidden" name="foto" value="<?php echo @$siswa['file']?>">
				<?php } ?>
			</td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td>
				<input type="file" name="foto">
			</td>
		</tr>
		<!-- Sampai sini, sebelum tombol Simpan -->
		<tr>
			<td colspan="3" align="center" height="60px"><input type="submit" value="Simpan" id="tombol"></td>
		</tr>
	</table>
</form>
</body>
</html>