<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 view index</title>
	<link rel="stylesheet" type="text/css" href="assets/hiasP.css"> <!-- Ini yang dulu -->
	<script type="text/javascript" src="assets/media/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/media/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/media/css/bootstrap.css">
	<!-- Toastr Plugin -->
	<link rel="stylesheet" type="text/css" href="assets/media/plugins/toastr/toastr.min.css">
	<script type="text/javascript" src="assets/media/plugins/toastr/toastr.min.js"></script>
</head>
<body class="bg-info">
<!-- Tambahkan ini -->
<form action="logout.php" id="logout" class="">
		<input type="submit" name="reset" value="Logout" class="btn btn-danger">
</form>
<!-- sampai sini -->
<fieldset>
<h1 id="h" class="text-center">Data Siswa</h1>
<form action="index.php" id="reset">
	<a href="tambah.php" class="btn btn-default">Tambah Data</a>
	<input type="submit" name="reset" value="Reset" class="btn btn-success">
</form>
<form method="GET" action="index.php" id="cari" class="form-control">
	&nbsp;Cari : <input type="text" name="search" value="<?= @$search ?>">
	<button type="submit" >Cari</button>
</form>
<table border="1" id="index" class="table">
	<thead>
		<tr class="tr">
			<th>No</th>
			<!-- tambah ini -->
			<th>Foto</th>
			<!-- sampai sini -->
			<th>NIS
				<a class="ascdsc" href="index.php?sort=nis&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=nis&order=desc">▼</a>
			</th>
			<th>Nama Lengkap
				<a class="ascdsc" href="index.php?sort=nama_lengkap&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=nama_lengkap&order=desc">▼</a>
			</th>
			<th>Jenis Kelamin
				<a class="ascdsc" href="index.php?sort=jenis_kelamin&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=jenis_kelamin&order=desc">▼</a>
			</th>
			<th>Kelas
				<a class="ascdsc" href="index.php?sort=kelas&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=kelas&order=desc">▼</a>
			</th>
			<th>Jurusan
				<a class="ascdsc" href="index.php?sort=jurusan&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=jurusan&order=desc">▼</a>
			</th>
			<th>Alamat
				<a class="ascdsc" href="index.php?sort=alamat&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=alamat&order=desc">▼</a>
			</th>
			<th>Golongan darah
				<a class="ascdsc" href="index.php?sort=golongan_darah&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=golongan_darah&order=desc">▼</a>
			</th>
			<th>Nama Ibu
				<a class="ascdsc" href="index.php?sort=nama_ibu&order=asc">▲</a>
				<a class="ascdsc" href="index.php?sort=nama_ibu&order=desc">▼</a>
			</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$i = 1;
			while ($siswa = $listSiswa->fetch_array()) {
		?>
		<tr>
			<td><?= $i++ ?></td>
			<td>
				<img src="<?php echo base_url()?>/assets/foto/<?php echo @$siswa['file']?>" width="80px" alt=" "/>
			</td>
			<td><?= $siswa['nis'] ?></td>
			<td><?= $siswa['nama_lengkap'] ?></td>
			<td><?= $siswa['jenis_kelamin'] ?></td>
			<!-- Ubah dari kelas menjadi nama_kelas  -->
			<!-- ( sesuai dengan yang ada di tabel t_kelas ) -->
			<td><?= $siswa['nama_kelas'] ?></td>
			<td><?= $siswa['jurusan'] ?></td>
			<td><?= $siswa['alamat'] ?></td>
			<td><?= $siswa['golongan_darah'] ?></td>
			<td><?= $siswa['nama_ibu'] ?></td>
			<td>
				<a href="edit.php?nis=<?= $siswa['nis']?>" class="btn btn-primary">Edit</a>
				<a href="delete.php?nis=<?= $siswa['nis']?>" class="btn btn-danger btnDelete">Delete</a>
			</td>
		</tr>
	    <?php } ?>
	</tbody>	
</table>
</fieldset>
<!-- Dari sini -->
<!-- kodingan Konfirmasi -->
<div class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title"></h4>
			</div>
			<div class="modal-body">
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary btnYa">Ya</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Tidak</button>
			</div>
		</div>
	</div>
</div>

<!-- kodingan untuk memunculkan konfirmasi dan Ketika klik Ya -->
<script type="text/javascript">
	$(function () {
		$(".btnDelete").on("click", function(e){
			e.preventDefault();

			var nama = $(this).parent().parent().children()[3];
			nama = $(nama).html();

			var tr = $(this).parent().parent();

			$(".modal").modal('show');
			$(".modal-title").html('Konfirmasi');
			$(".modal-body").html('Anda yakin ingin menghapus <b>' + nama + '</b> ?');

			var href = $(this).attr('href');

			$('.btnYa').off();
			$('.btnYa').on('click', function(){ 
				$.ajax({
					'url'	  : href,
					'type'	  : 'POST',
					'success' : function(){
							$(".modal").modal('hide');
							tr.fadeOut();

							toastr.success('Data berhasil terhapus','infomasi');
						}
					});
				});
			});
		});
</script>
<!-- Sampai sini -->
</body>
</html>