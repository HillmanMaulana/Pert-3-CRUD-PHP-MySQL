<!DOCTYPE html>
<html>
<head>
	<title>Ramdanr Pertemuan 27, 28, 29, & 30 view login</title>
	<link rel="stylesheet" type="text/css" href="assets/hiasP.css">
</head>
<body>
	<form id="login" class="form-horizontal" action="login.php" method="POST">
		<table>
			<tr>
				<th align="center" colspan="2" id="login">Login</th>
				<td></td>
			</tr>
			<tr>
				<td>&nbsp;&nbsp;<label class="col-sm-2 control-label">Username</label></td>
				<td><input type="text" name="username" class="form-control"></td>
			</tr>
			<tr>
				<td>&nbsp;&nbsp;<label class="col-sm-2 control-label">Password</label></td>
				<td><input type="password" name="password" class="form-control"></td>
			</tr>
			<tr>
				<td><label class="col-sm-2 control-label"></label></td>
				<td><button type="submit" class="btn">Login</button></td>
			</tr>
		</table>
</form>
</body>
</html>